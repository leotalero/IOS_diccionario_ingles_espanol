//
//  TableCell.h
//  diccionario1
//
//  Created by Leonardo Talero on 11/17/15.
//  Copyright © 2015 unir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *labelizquierda;
@property (weak, nonatomic) IBOutlet UILabel *labelderecha;


@end
