//
//  AppDelegate.h
//  diccionario1
//
//  Created by Leonardo Talero on 11/16/15.
//  Copyright © 2015 unir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

