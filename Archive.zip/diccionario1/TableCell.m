//
//  TableCell.m
//  diccionario1
//
//  Created by Leonardo Talero on 11/17/15.
//  Copyright © 2015 unir. All rights reserved.
//

#import "TableCell.h"

@implementation TableCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
